INSERT INTO `units` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Штучно', NULL, NULL),
(2, 'Граммы', NULL, NULL),
(3, 'Миллилитры', NULL, NULL),
(4, 'Литры', NULL, NULL),
(5, 'Чайные ложки', NULL, NULL),
(6, 'Столовые ложки', NULL, NULL);
