<?php $__currentLoopData = $toppings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $records_number=  \App\Models\Topping::where('id', '<=', $topping->id)->count()?>

    <tr class="table-container" id="record-<?php echo e($topping->id); ?>">
        <td class="text-center"><?php echo e($records_number); ?> </td>
        <td><?php echo e($topping->name); ?></td>
        <td><?php echo e($topping->unit->getUnitName()); ?></td>
        <td><?php echo e($topping->created_at); ?></td>
        <?php if(auth()->user()->can('manage records')): ?>
            <td class="table-content" id="record-btn-<?php echo e($topping->id); ?>">
                <div class="table-buttons text-center">
                    <button type="button" data-number="<?php echo e($records_number); ?>" data-unit-id="<?php echo e($topping->unit->id); ?>" data-name="<?php echo e($topping->name); ?>" data-id="<?php echo e($topping->id); ?>" class="btn btn-primary update-record"><i class="fa-solid fa-pen"></i></button>
                    <button class="btn btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal" data-table="toppings" data-id="<?php echo e($topping->id); ?>">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </td>
        <?php endif; ?>
    </tr>
    <tr class="d-none" id="update-record-<?php echo e($topping->id); ?>"></tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr id="new-record"></tr>

<?php if($toppings->count() == 0): ?> 
<tr id="no-records">
    <td colspan="12" align="center" class="h-100 align-items-center">
        <i class="fa-solid fa-file-circle-xmark records-missing-icon"></i>
        <p>Записи отсутствуют</p>
    </td>
</tr>
<?php endif; ?>
<?php /**PATH C:\Users\user\Programs\OSPanel\domains\restorane\resources\views/toppings/records.blade.php ENDPATH**/ ?>