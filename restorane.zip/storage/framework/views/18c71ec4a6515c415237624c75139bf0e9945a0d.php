<?php $__env->startSection('content'); ?>

    <?php
        $no_finished_orders_count = 0;
        foreach ($orders as $order) {
            $has_unfinished_food = false;
            foreach ($foods as $food) {
                $order_number = DB::table('food_orders')
                    ->where('order_id', $order->id)
                    ->where('food_id', $food->id)
                    ->where('is_completed', false)
                    ->count();

                if ($order_number > 0 &&  $order->order_status == 'Оплачено') {
                    $has_unfinished_food = true;

                    break;
                }
            }

            if ($has_unfinished_food) {
                $no_finished_orders_count++;
            }
        }
    ?>

    <div id="alert"></div>
    <div class="d-flex justify-content-center w-100 mb-3">
        <a href="<?php echo e(route('orders.index')); ?>">
            <button id="" type="button" class=" btn fw-bold me-2 btn-outline-dark">Новые заказы
                <span id="cart-count" class="badge rounded-4 bg-danger "><?php echo e($no_finished_orders_count); ?> </span>
            </button>
        </a>
        <a href="<?php echo e(route('orders.history')); ?>">
            <button  type="button" class="btn fw-bold ms-2 btn-outline-dark">История заказов</button>
        </a>
    </div>
    <table class="table table-bordered  table-hover">
        <thead>
        <tr>
            <th  class="buttons-column id-column">
                #
            </th>
            <th class="buttons-column ">
                Клиент
            </th>
            <th class="buttons-column ">
                Столик
            </th>
            <th class="buttons-column">
                Количество
            </th>
            <th class="buttons-column">
                Дата заказа
            </th>

                <th class="buttons-column" scope="col">Подробнее</th>
        </tr>
        </thead>
        <tbody  id="table">

        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php $order_num=  \App\Models\order::where('id', '<=', $order->id)->count();
             $food_count = DB::table('food_orders')
                ->where('order_id', $order->id)
                ->count();

             $no_finished_orders_count = 0;

            $has_unfinished_food = false;
            foreach ($foods as $food) {
                $order_number = DB::table('food_orders')
                    ->where('order_id', $order->id)
                    ->where('food_id', $food->id)
                    ->where('is_completed', false)
                    ->count();

                if ($order_number > 0) {
                    $has_unfinished_food = true;
                    break;
                }
            }

            if ($has_unfinished_food) {
                $no_finished_orders_count++;
            }

            ?>
            <?php if($no_finished_orders_count && $order->order_status == 'Оплачено'): ?>
            <tr class="table-container" id="ordered-food-">
                <td class="id-column fw-bold" >Заказ №<?php echo e($order_num); ?></td>

                <td><?php echo e($order->user->name); ?></td>
                <td><?php echo e($order->hall->name); ?> зал<br><?php echo e($order->table_number); ?> столик</td>
                <td>
                    <div class="d-flex flex-row align-items-center ">
                        <h6 class="m-3 bg-black"><?php echo e($food_count); ?> блюдо</h6>
                    </div>
                </td>
                <td><?php echo e($order->created_at); ?></td>


                <td class="text-center">
                    <div class="table-buttons text-center">
                        <button type="button" id="show-more-<?php echo e($order->id); ?>" data-id="<?php echo e($order->id); ?>"  class="fw-bold show-more btn btn-secondary">
                            <i class="fa-solid fa-angle-up"></i> Подробнее
                        </button>
                        <button type="button" id="show-less-<?php echo e($order->id); ?>" data-id="<?php echo e($order->id); ?>" class="fw-bold show-less btn btn-secondary d-none">
                            <i class="fa-solid fa-angle-down"></i> Скрыть
                        </button>
                    </div>
                </td>
            </tr>


        <tbody id="show-order-more-<?php echo e($order->id); ?>" class="d-none">
        <tr class="bg-dark" style="color: #fff">

            <td class="buttons-column" colspan="2">
                <b>Блюдо</b>
            </td>

            <td class="buttons-column" colspan="2">
                <b>Заказано</b>
            </td>
            <td class="buttons-column">
                <b>Сделано</b>
            </td>
            <td class="buttons-column" >
                <b>Статус</b>
            </td>




            <?php $__currentLoopData = $order->food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $food_price = $food->price;
                    $food_quantity = $food->pivot->quantity;
                    $total_sum = $food_price * $food_quantity;
                ?>
                <tr class="table-container" id="ordered-food-">
                    <td><img width="150px" src="<?php echo e(asset('storage/files/' . $food->image)); ?>" class="rounded" alt="..."></td>
                    <td><?php echo e($food->name); ?></td>
                    <td colspan="2">
                        <div class="d-flex flex-row align-items-center" >
                            <h6 class="m-3 bg-black" style="width: max-content;"><?php echo e($food->pivot->quantity); ?> порций</h6>
                        </div>
                    </td>
                    <td >
                        <div class="d-flex flex-row align-items-center justify-content-center" >
                            <button type="button" <?php if($food->pivot->is_completed == false): ?> disabled <?php endif; ?> id="order-minus-<?php echo e($order->id); ?>-<?php echo e($food->id); ?>" data-id="<?php echo e($food->id); ?>" data-order="<?php echo e($order->id); ?>" data-quantity="<?php echo e($food->pivot->quantity); ?>" data-is-complete="<?php echo e($food->pivot->is_completed); ?>" class="order-minus btn btn-secondary"><i class="fa-solid fa-minus"></i></button>
                            <h6 id="food-quantity-complete-<?php echo e($order->id); ?>-<?php echo e($food->id); ?>" class="m-3 bg-black" style="width: max-content;"><?php if($food->pivot->is_completed == true): ?><?php echo e($food->pivot->quantity); ?> <?php else: ?> 0 <?php endif; ?></h6>
                             <button type="button" <?php if($food->pivot->is_completed == true): ?> disabled <?php endif; ?> id="order-plus-<?php echo e($order->id); ?>-<?php echo e($food->id); ?>"  data-id="<?php echo e($food->id); ?>" data-order="<?php echo e($order->id); ?>" data-quantity="<?php echo e($food->pivot->quantity); ?>" class="order-plus btn btn-secondary"><i class="fa-solid fa-plus"></i></button>

                        </div>
                    </td>
                    <td>
                        <?php if($food->pivot->is_completed == false): ?>
                            <div id="is_completed-<?php echo e($order->id); ?>-<?php echo e($food->id); ?>" class="btn btn-secondary fw-bold w-100">
                                <i class="fa-solid fa-utensils"></i> Готовиться
                            </div>
                        <?php endif; ?>
                        <?php if($food->pivot->is_completed == true): ?>
                            <div id="is_completed-<?php echo e($order->id); ?>-<?php echo e($food->id); ?>" class="btn btn-success  fw-bold w-100">
                                <i class="fa-solid fa-check"></i> Приготовлено
                            </div>
                        <?php endif; ?>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr><td colspan="12" class="p-4 border-0"></td>
            </tr>

        </tbody>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr class="d-none" id="no-records">
            <td colspan="12" align="center" class="h-100 align-items-center">
                <i class="fa-solid fa-store-slash records-missing-icon"></i>
                <p>Корзина пуста</p>
            </td>
        </tr>
        </tbody>
    </table>

    <div class="col-12"><?php echo e($orders->links('vendor.pagination.bootstrap-4')); ?></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('.show-more').click(function (e){
            e.preventDefault();

            var order = $(this)
            var id = order.data('id')

            $('#show-more-'+id).addClass('d-none')
            $('#show-less-'+id).removeClass('d-none')

            $('#show-order-more-'+id).removeClass('d-none')


        })
        $('.show-less').click( function (e){
            e.preventDefault();

            var order = $(this)
            var id = order.data('id')

            $('#show-more-'+id).removeClass('d-none')
            $('#show-less-'+id).addClass('d-none')

            $('#show-order-more-'+id).addClass('d-none')

        })


        $('.order-plus').click(function (e) {
            e.preventDefault();
            var food = $(this)
            var id = food.data('id')
            var order = food.data('order')
            var quantity = food.data('quantity')


            var result = $('#food-quantity-complete-'+order+'-'+id).html()
            $('#order-minus-'+order+'-'+id).prop('disabled', false);
            if(quantity > result){
                result +++ 1;
                $('#food-quantity-complete-'+order+'-'+id).html(result);

            }


            if(quantity == result){



                console.log($('#order-minus-'+order+'-'+id).data('is-complete'))

                $('#order-plus-'+order+'-'+id).prop('disabled', true);
                var complete = `
                <div id="is_completed-${order}-${id}" class="btn btn-success  fw-bold w-100">
                                <i class="fa-solid fa-check"></i> Приготовлено
                            </div>`
                $('#is_completed-'+order+'-'+id).replaceWith(complete);


                setTimeout(function() {
                    // Код, который будет выполнен после задержки
                    var quantity = food.data('quantity')
                    var result = $('#food-quantity-complete-'+order+'-'+id).html()
                    if(quantity == result) {
                        $('#order-minus-'+order+'-'+id).data('is-complete', 1);
                        $.ajax({
                            url: '<?php echo e(route('orders.complete')); ?>',
                            method: 'post',
                            data: {
                                order_id: order,
                                food_id: id,
                                is_completed: 1,
                            },
                        })
                    }
                }, 5000);

            }
        })

        $('.order-minus').click(function (e) {
            e.preventDefault();
            var food = $(this)
            var id = food.data('id')
            var order = food.data('order')
            var quantity = food.data('quantity')
            var result = $('#food-quantity-complete-'+order+'-'+id).html()
            var complete = $('#order-minus-'+order+'-'+id).data('is-complete');

            console.log(complete)

            if(quantity >= result && result != 0){
                result -= 1;
                food.data('complete', 0);
                $('#food-quantity-complete-'+order+'-'+id).html(result);
                $('#order-plus-'+order+'-'+id).prop('disabled', false);

                setTimeout(function() {
                    // Код, который будет выполнен после задержки
                    var quantity = food.data('quantity')
                    var result = $('#food-quantity-complete-'+order+'-'+id).html()
                    if(quantity > result && complete === 1) {
                        $('#order-minus-'+order+'-'+id).data('is-complete', 0);
                        $.ajax({
                            url: '<?php echo e(route('orders.complete')); ?>',
                            method: 'post',
                            data: {
                                order_id: order,
                                food_id: id,
                                is_completed: 0,
                            },
                        })
                    }
                }, 5000);

                if(result == 0){

                    $('#order-minus-'+order+'-'+id).prop('disabled', true);
                }



                var not_complete = `
                 <div id="is_completed-${order}-${id}" class="btn btn-secondary fw-bold w-100">
                                <i class="fa-solid fa-utensils"></i> Готовиться
                            </div>`
                $('#is_completed-'+order+'-'+id).replaceWith(not_complete);
            }


        })
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\restorane\resources\views/orders/index.blade.php ENDPATH**/ ?>