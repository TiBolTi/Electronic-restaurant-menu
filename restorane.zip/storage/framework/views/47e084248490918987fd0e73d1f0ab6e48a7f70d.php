<?php $__env->startSection('content'); ?>

    <h3 class="mb-5 mt-3">Пользователи</h3>
    <div id="alert"></div>

    <div class="d-flex justify-content-center w-100 mb-3">
        <a href="<?php echo e(route('employees.index')); ?>">
            <button id="" type="button" class=" btn fw-bold me-2 btn-outline-dark">Сотрудники
            </button>
        </a>
        <a href="<?php echo e(route('employees.clients')); ?>">
            <button  type="button" class="btn fw-bold ms-2 btn-outline-dark">Пользователи</button>
        </a>
    </div>

    <table class="table table-bordered table-hover">
        <thead>
        <tr>
            <th class="id-column col-2">
                Имя
            </th>
            <th class="id-column col-auto">
                Почта
            </th>
            <th class="id-column col-2">
                Роль
            </th>
            <th class="date-column">
                Зарегистрирован
            </th>
        </tr>
        </thead>

        <tbody  id="table">


        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->hasRole('client')): ?>

                <tr class="table-container" id="record-<?php echo e($user->id); ?>">
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <?php if(auth()->user()->can('manage staff')): ?>
                            <select data-id="<?php echo e($user->id); ?>" class="form-select user-role" aria-label="Default select example">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($user->roles()->pluck('name')->implode(', ') == $role->name): ?> selected <?php endif; ?>  value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php else: ?>
                            <?php echo e($user->roles()->pluck('name')->implode(', ')); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($user->created_at); ?></td>
                </tr>
                <tr class="d-none" id="update-record-<?php echo e($user->id); ?>"></tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr id="new-record"></tr>

        <?php if($users->count() == 0): ?> 
        <tr id="no-records">
            <td colspan="12" align="center" class="h-100 align-items-center">
                <i class="fa-solid fa-file-circle-xmark records-missing-icon"></i>
                <p>Записи отсутствуют</p>
            </td>
        </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <div class="col-12"><?php echo e($users->links('vendor.pagination.bootstrap-4')); ?></div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('.user-role').on('change', function () {
            var user = $(this);
            var id = user.data('id');
            var selectedRole = user.val();


            $.ajax({
                url: '<?php echo e(route('employees.roleUpdate')); ?>',
                method: 'POST',
                data: {
                    id: id,
                    role: selectedRole
                },
                success: function (data) {
                    $('#alert').html(`
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <b>Успех!</b> Роль <b>${name}</b>, успешно изменина на <b>${selectedRole}</b>!
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>`)

                },

                error: function (data) {
                    // Сообщение об ошибке
                    $('#alert').html(`
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong>Ошибка!</strong> Не удалось обновить роль у пользователя!
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>`)
                }
            });

        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\restorane\resources\views/employees/clients.blade.php ENDPATH**/ ?>