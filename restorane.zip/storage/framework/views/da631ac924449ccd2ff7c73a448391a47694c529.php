<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $records_number=  \App\Models\Category::where('id', '<=', $category->id)->count()?>

    <tr class="table-container" id="record-<?php echo e($category->id); ?>">
        <td class="text-center"><?php echo e($records_number); ?> </td>
        <td><img width="200px" class="img rounded" src="<?php echo e(asset('storage/files/' . $category->image)); ?>" alt=""></td>
        <td><?php echo e($category->name); ?></td>
        <td>
            <?php if($category->is_publish == 1): ?>
                Опубликовано
            <?php else: ?>
                Не опубликовано
            <?php endif; ?>
        </td>
        <td><?php echo e($category->created_at); ?></td>
        <?php if(auth()->user()->can('manage records')): ?>
            <td class="table-content" id="record-btn-<?php echo e($category->id); ?>">
                <div class="table-buttons text-center">
                    <button type="button" data-publish="<?php echo e($category->is_publish); ?>" data-number="<?php echo e($records_number); ?>"  data-name="<?php echo e($category->name); ?>" data-id="<?php echo e($category->id); ?>" class="btn btn-primary update-record"><i class="fa-solid fa-pen"></i></button>
                    <button class="btn btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal" data-table="categories" data-id="<?php echo e($category->id); ?>">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </td>
        <?php endif; ?>
    </tr>
    <tr class="d-none" id="update-record-<?php echo e($category->id); ?>"></tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr id="new-record"></tr>

<?php if($categories->count() == 0): ?> 
<tr id="no-records">
    <td colspan="12" align="center" class="h-100 align-items-center">
        <i class="fa-solid fa-file-circle-xmark records-missing-icon"></i>
        <p>Записи отсутствуют</p>
    </td>
</tr>
<?php endif; ?>
<?php /**PATH C:\Users\user\Programs\OSPanel\domains\restorane\resources\views/categories/records.blade.php ENDPATH**/ ?>