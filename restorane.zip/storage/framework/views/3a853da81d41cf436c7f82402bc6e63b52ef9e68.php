

<?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $records_number=  \App\Models\Food::where('id', '<=', $food->id)->count()?>

    <tr class="table-container" id="record-<?php echo e($food->id); ?>">
        <td class="text-center"><?php echo e($records_number); ?> </td>
        <td><img width="200px" class="img rounded" src="<?php echo e(asset('storage/files/' . $food->image)); ?>" alt=""></td>
        <td><?php echo e($food->name); ?></td>
        <td><?php echo e($food->price); ?> сом</td>

        <td>
            <?php if($food->is_publish == 1): ?>
                Опубликовано
            <?php else: ?>
                Не опубликовано
            <?php endif; ?>
        </td>
        <td><?php echo e($food->created_at); ?></td>

        <td class="table-content" id="record-btn-<?php echo e($food->id); ?>">
            <div class="table-buttons text-center">
                <button type="button" id="more-about-<?php echo e($food->id); ?>" data-ingredients="<?php echo e($toppings); ?>" data-categories="<?php echo e($categories); ?>" data-publish="<?php echo e($food->is_publish); ?>" data-number="<?php echo e($records_number); ?>"  data-name="<?php echo e($food->name); ?>" data-id="<?php echo e($food->id); ?>" class="btn btn-primary more-about">Подробнеe</button>
                <button type="button" id="hide-more-about-<?php echo e($food->id); ?>" data-id="<?php echo e($food->id); ?>" class="btn btn-secondary hide-more-about d-none">Скрыть</button>
            </div>
        </td>

    </tr>


    <tr id="more-about-record-<?php echo e($food->id); ?>" class="d-none">
        <td colspan="12">
            <div class="d-flex justify-content-around">
                <div class="d-flex flex-column mt-3 ms-5 w-50">
                    
                    <div class="mb-3">
                        <label for="input-name" class="form-label">Название</label>
                        <h5><?php echo e($food->name); ?></h5>
                    </div>
                    
                    <div class="mb-3 w-75">
                        <label for="input-desc" class="form-label">Описание</label>
                        <h6 style="overflow-wrap: anywhere;"><?php echo e($food->description); ?></h6>
                    </div>

                    
                    <label for="input-price" class="form-label">Цена</label>
                    <div class="input-group mb-3">
                        <h5><?php echo e($food->price); ?> сом</h5>

                    </div>
                    
                    <div class="col-auto form-check">
                        <input class="form-check-input" name="is_vegan" type="checkbox"  <?php if($food->is_vegan == 1): ?> checked <?php endif; ?> disabled>
                        <label class="form-check-label" id="check-is-vegan-label" for="check-is-vegan" >Это веганское блюдо</label>
                    </div>
                    
                    <div class="col-auto form-check">
                        <input class="form-check-input" name="is_special" type="checkbox"   <?php if($food->is_special == 1): ?> checked <?php endif; ?> disabled>
                        <label class="form-check-label"  for="check-is-special">Это специальное блюдо</label>
                    </div>
                    
                    <div class="col-auto form-check form-switch mt-3">
                        <input class="form-check-input" name="is_publish" type="checkbox"  <?php if($food->is_publish == 1): ?> checked <?php endif; ?> disabled>
                        <label class="form-check-label"  for="check-is-publish">Опубликовать блюдо</label>
                    </div>
                </div>

                <div class="d-flex flex-column justify-content-start w-50 mt-3 me-5 flex-column">
                    <label for="input-topping" class="form-label">Категории</label>
                    <div class="mb-3 d-flex flex-column">

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->is_publish == true && $food->category->contains($category)): ?>
                                <h5><span class="badge bg-primary"><?php echo e($category->name); ?></span></h5>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="flex-wrap d-flex mb-5"></div>

                    <label for="input-topping" class="form-label mt-5">Ингредиенты</label>
                    <div class="mb-3 d-flex flex-column h-50 flex-wrap">
                        <?php $__currentLoopData = $food->topping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $quantity = $topping->pivot->quantity;
                            ?>
                            <h5><span class="badge bg-success"><?php echo e($topping->name); ?> <?php if($quantity): ?> - <?php echo e($quantity); ?> <?php echo e($topping->unit->getAbbreviationUnit()); ?><?php endif; ?></span></h5>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="flex-wrap d-flex"></div>
                </div>
            </div>
            <?php if(auth()->user()->can('manage records')): ?>
                <div class="col-auto text-center mt-3 mb-3">
                    <button type="submit" data-id="<?php echo e($food->id); ?>" class="btn btn-success update-record"><i class="fa-solid fa-pen"></i> Изменить запись</button>
                    <button class="btn btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal" data-table="food" data-id="<?php echo e($food->id); ?>">
                        <i class="fa-solid fa-trash"></i> Удалить
                    </button>
                </div>
            <?php endif; ?>
        </td>
    </tr>
    <tr>
        <td colspan="12" id="update-record-<?php echo e($food->id); ?>" class="d-none">
            <form action="" id="update-form-<?php echo e($food->id); ?>" method="POST" class="row g-3 d-flex justify-content-center align-items-center">
                <?php echo csrf_field(); ?>
                <div class="d-flex justify-content-around">
                    <div class="d-flex flex-column mt-3">
                        
                        <div class="mb-3">
                            <label for="update-input-name-<?php echo e($food->id); ?>" class="form-label">Название</label>
                            <input id="update-input-name-<?php echo e($food->id); ?>" type="text" value="<?php echo e($food->name); ?>" name="name" class="form-control" placeholder="Введите название блюда">
                        </div>
                        
                        <div class="mb-3">
                            <label for="update-input-desc-<?php echo e($food->id); ?>" class="form-label">Описание</label>
                            <textarea class="form-control" name="description" id="update-input-desc-<?php echo e($food->id); ?>" placeholder="Введите описание для вашего блюда" rows="3"><?php echo e($food->description); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="update-image-input-<?php echo e($food->id); ?>" class="form-label">Изображение</label>
                            <input type="file" accept="image/*" name="image" id="update-image-input-<?php echo e($food->id); ?>" class="form-control" required>
                        </div>
                        
                        <label for="update-input-price-<?php echo e($food->id); ?>" class="form-label">Цена</label>
                        <div class="input-group mb-3">
                            <input type="number" class="form-control" value="<?php echo e($food->price); ?>" name="price" id="update-input-price-<?php echo e($food->id); ?>" placeholder="Укажите цену блюда">
                            <span class="input-group-text">сом</span>
                        </div>
                        
                        <div class="col-auto form-check">
                            <input class="form-check-input" name="is_vegan" type="checkbox" id="update-check-is-vegan-<?php echo e($food->id); ?>" <?php if($food->is_vegan == 1): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="update-check-is-vegan-<?php echo e($food->id); ?>">Это веганское блюдо</label>
                        </div>
                        
                        <div class="col-auto form-check">
                            <input class="form-check-input" name="is_special" type="checkbox" id="update-check-is-special-<?php echo e($food->id); ?>" <?php if($food->is_special == 1): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="update-check-is-special-<?php echo e($food->id); ?>">Это специальное блюдо</label>
                        </div>
                        
                        <div class="col-auto form-check form-switch mt-3">
                            <input class="form-check-input" name="is_publish" type="checkbox" id="update-check-is-publish-<?php echo e($food->id); ?>" <?php if($food->is_publish == 1): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="update-check-is-publish-<?php echo e($food->id); ?>">Опубликовать блюдо</label>
                        </div>
                    </div>
                    <div class="d-flex flex-column justify-content-start w-50 mt-3 flex-column">
                        <label for="input-topping" class="form-label">Категории</label>
                        <div class="mb-3 d-flex" id="update-category-list-<?php echo e($food->id); ?>">
                            <select id="update-input-category-<?php echo e($food->id); ?>" class="form-select me-2">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($category->is_publish == true && !$food->category->contains($category)): ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                            <button type="button" id="update-add-category-<?php echo e($food->id); ?>" class="btn d-block btn-success form-control">Добавить Категорию</button>
                        </div>
                        <div class="flex-wrap d-flex mb-5" id="update-category-records-<?php echo e($food->id); ?>">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->is_publish == true && $food->category->contains($category)): ?>
                                    <div style="width: 48%; margin-left: 5px; margin-bottom: 3px; height: fit-content" class="input-group update-category-input-group-<?php echo e($food->id); ?>">
                                        <button class="btn btn-danger update-delete-category-<?php echo e($food->id); ?>" type="button"><i class="fa-solid fa-xmark"></i></button>
                                        <input class="form-control" type="hidden" name="update-category-<?php echo e($food->id); ?>" value="<?php echo e($category->id); ?>">
                                        <span class="input-group-text update-category-name-<?php echo e($food->id); ?> " style="width: 85%"><?php echo e($category->name); ?></span>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>



                        <label for="update-input-topping-<?php echo e($food->id); ?>" class="form-label mt-5">Ингредиенты</label>
                        <div class="mb-3 d-flex" id="update-topping-list-<?php echo e($food->id); ?>">
                            <select id="update-input-topping-<?php echo e($food->id); ?>" class="form-select me-2">
                                <?php $__currentLoopData = $toppings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$food->topping->contains($topping)): ?>
                                        <option data-unit="<?php echo e($topping->unit->getAbbreviationUnit()); ?>" value="<?php echo e($topping->id); ?>"><?php echo e($topping->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="button" id="update-add-topping-<?php echo e($food->id); ?>" class="btn d-block btn-success form-control">Добавить ингредиент</button>
                        </div>
                        <div class="flex-wrap d-flex" id="update-topping-records-<?php echo e($food->id); ?>">

                            <?php $__currentLoopData = $food->topping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($food->topping->contains($topping)): ?>
                                    <?php
                                        $quantity = $topping->pivot->quantity;
                                    ?>
                                    <div style="width: 48%; margin-left: 5px; margin-bottom: 3px; height: fit-content" class="input-group update-topping-input-group-<?php echo e($food->id); ?>">
                                        <button class="btn btn-danger update-delete-topping-<?php echo e($food->id); ?>" type="button"><i class="fa-solid fa-xmark"></i></button>
                                        <span class="input-group-text update-topping-name-<?php echo e($food->id); ?>"><?php echo e($topping->name); ?></span>
                                        <input class="form-control" type="hidden" name="update-topping-<?php echo e($food->id); ?>" value="<?php echo e($topping->id); ?>">
                                        <input class="form-control" type="number" name="update-quantity-<?php echo e($food->id); ?>" value="<?php if($quantity): ?><?php echo e($quantity); ?><?php endif; ?>" placeholder="Вес / Количество">
                                        <span class="input-group-text update-topping-unit-<?php echo e($food->id); ?>"><?php echo e($topping->unit->getAbbreviationUnit()); ?></span>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
                <div class="col-auto">
                    <button type="submit" id="complete-update-<?php echo e($food->id); ?>" class="btn btn-success">Обновить запись</button>
                    <button type="button" id="cancel-update-<?php echo e($food->id); ?>" class="btn btn-danger">Отмена</button>
                </div>
            </form>
        </td>
    </tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<tr id="new-record"></tr>



<?php /**PATH C:\Users\user\Programs\OSPanel\domains\restorane\resources\views/food/records.blade.php ENDPATH**/ ?>